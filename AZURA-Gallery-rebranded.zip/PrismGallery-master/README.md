# AZURA Gallery

AZURA is an offline-first Android photo and video gallery. It does not request Internet permission and keeps gallery operations local to the device.

## Branding
- App name: AZURA
- Android application ID: `com.azura.gallery`
- Dark theme: near-black/black with cyan-blue accent
- Light theme: white with cyan-blue accent
- Launcher emblem: AZURA aperture

## Attribution and license
This project is a derivative of **Prism Gallery**. Original source license and notices are preserved in `LICENSE`. This rebrand does not remove upstream copyright or license obligations.


## Build
Use Android Studio or GitHub Actions to run `./gradlew assembleDebug`.
